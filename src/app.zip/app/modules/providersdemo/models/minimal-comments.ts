export abstract class MinimalCommentsService {
  getComments: () => Array<string>;
}
