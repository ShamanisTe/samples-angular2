export interface Comments {
  getComments();
  getAPIKEY();
}
