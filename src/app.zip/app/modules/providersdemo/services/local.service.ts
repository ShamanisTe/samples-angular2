import { Injectable } from '@angular/core';

@Injectable()
export class LocalService {
  
  constructor() {
  }
  
  getValue() {
    return "bonjour";
  }
  
}
