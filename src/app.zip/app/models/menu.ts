export interface Menu {
    link:string;
    text:string;
}
