export interface ChangeCmp {
    hasChanges();
}
